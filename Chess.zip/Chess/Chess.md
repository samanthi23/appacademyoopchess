# private vs public

private methods can only be called in the defining class

example: thing.implicit_receiver #=> "hello world"