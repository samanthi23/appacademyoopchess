class Piece
    
end